module.exports = {
  "root": true,
  "parser": "vue-eslint-parser",
  "plugins": [
   "jsx-a11y", "import", "html"
  ],
  "env": {
      "browser": true,
      "commonjs": true,
      "es6": true,
      "node": true,
      "mocha": true
      
  },
  "parserOptions": {
    "parser": "babel-eslint",
    "ecmaVersion": 2017,
    "sourceType": "module",
    "ecmaFeatures": {
        "jsx": true
    }
},
'settings': {
  'import/resolver': {
    'webpack': {
      'config': 'build/webpack.base.config.js'
    }
  }
},
  "globals": {
    "__DEV__": true,
      "__CLIENT__":true,
      "__SERVER__": true,
      "__DISABLE_SSR__": false,
      "__DEVTOOLS__": true,
      "socket": true,
     "modules": true,
      "AppError":true
  },
  "extends": ["pedant", "eslint:recommended", "plugin:vue/base", 'plugin:vue/essential', 'airbnb-base'],
  "rules": {
      "no-shadow": "off",
      "eslint no-trailing-spaces": 0,
     "prefer-arrow-callback": [ "error", { "allowNamedFunctions": true }],
      "require-jsdoc": 0,
      "no-underscore-dangle": "off",
      'generator-star-spacing': 0,
    "no-invalid-this":0,
    'arrow-parens': 0,
      "array-bracket-spacing": [2, "never"],
      "arrow-spacing": 2,
      "brace-style": [2, "1tbs", { "allowSingleLine": true }],
      "comma-spacing": [2, { "before": false, "after": true }],
      "comma-style": 2,
      "consistent-this": [2, "_this"],
      "curly": [2, "multi-line", "consistent"],
      "dot-notation": 0,
      "dot-location": [2, "property"],
      "eqeqeq": 2,
      "no-plusplus": 0,
      "eol-last": 2,
      "func-call-spacing": 2,
      "guard-for-in": 2,
      "indent": [2, 4, { "SwitchCase": 1 }],
      "key-spacing": [2, {
          "beforeColon": false,
          "afterColon": true
      }],
      "keyword-spacing": [2, {
          "overrides": {
              "else": { "before": true, "after": true },
              "while": { "before": true, "after": true },
              "catch": { "before": true, "after": true },
              "if": { "after": true },
              "for": { "after": true },
              "do": { "after": true },
              "switch": { "after": true },
              "return": { "after": true },
              "try": { "after": true }
          }
      }],
      "linebreak-style": [2, "unix"],
      "parser.parse is not a function":0,
      "newline-before-return": 2,
      "no-eval": 2,
      "no-caller": 2,
      "no-console":["error",{"allow": ["warn", "log", "error"]}],
      "new-cap": [2, { "capIsNewExceptions": ["List", "Map", "Set"] }],      
  
  "import/default": 0,
  "import/no-duplicates": 0,
  "import/named": 0,
  "import/namespace": 0,
  "import/no-unresolved": 0,
     "comma-dangle": 0,  
     
      "jsx-a11y/no-static-element-interactions":0,
      "jsx-a11y/click-events-have-key-events":0,
      "jsx-a11y/no-noninteractive-element-interactions":0,
     
      "import/no-named-as-default":0,
      "import/no-named-as-default-member":0,
      "import/prefer-default-export":0,
      "prefer-destruturing":0,
      "import/extensions":0,
      "newIsCap": false,
      "jsx-a11y/anchor-is-valid":0,
      "max-len": ["error", { "code": 140 }],
      "no-unexpected-multiline":2,
      "no-cond-assign"    : [2, "except-parens"],
      "no-empty": 2,
      "allowForLoopAfterthoughts": true,
      "max-len": "off",
      "no-extra-semi": 2,
      "import/no-extraneous-dependencies":0,
      "no-loop-func": 2,
      "no-multi-str": 2,
      "no-multiple-empty-lines": [2, { "max": 1 }],
      "no-mixed-spaces-and-tabs": 2,
      "no-nested-ternary": 2,
      "no-new-func": 2,
      "no-new-wrappers": 2,
      "no-redeclare": 2,
      "no-trailing-spaces": 2,
            "no-undef": 2,
      "no-unneeded-ternary": 2,
      "no-unused-vars": 2,
      "no-unused-expressions": 0,
      "no-with": 2,
      "max-depth": [2, 4],
      "radix":0,
      "max-len": [2, { "code": 120 }],
      "object-curly-spacing": [2, "always"],
      "operator-linebreak": [2, "after"],
      "quotes": [2, "single", "avoid-escape"],
      "quote-props": [2, "as-needed", { "unnecessary": true, "keywords": true }],
      "semi": [2, "always"],
      "space-before-function-paren": [2, "never"],
      "space-before-blocks": 0,
      "space-in-parens": 2,
      'prefer-promise-reject-errors': 0,
    'import/prefer-default-export': 0,
      "space-infix-ops": 2,
      "space-unary-ops": [2, {
          "words": true,
          "nonwords": false
      }],
     "yoda": [2, "never"],
      "wrap-iife": [2, "any"],
      'import/extensions': ['error', 'always', {
        js: 'never',
        vue: 'never',
        jsx: 'never',
        json: 'never'
      }],
      // disallow reassignment of function parameters
      // disallow parameter object manipulation except for specific exclusions
      'no-param-reassign': ['error', {
        props: true,
        ignorePropertyModificationsFor: [ 
          'ctx',
          'html',
          'router',
          'context',
          'state', // for vuex state
          'acc', // for reduce accumulators
          'e'
          // for e.returnvalue
        ]
      }],
      'import/no-webpack-loader-syntax': 'off',
      'import/no-extraneous-dependencies': "off",
      'import/no-extraneous-dependencies': ['error', {
        optionalDependencies: ['test/unit/index.js']
      }],
      'no-debugger': process.env.NODE_ENV === 'production' ? 2 : 0
  }
}