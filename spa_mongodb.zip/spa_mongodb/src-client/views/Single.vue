<template>
  <section class="container" v-if="article">
  <div class="card-body" v-if="!isAdmin">
  <h1 class="intro">Article View</h1>
  <div id='root' class="card mb-3">
    <label class="label">article title</label>
    <!--input class="input is-medium" type='text' id='input' v-model='article.title'!-->
    <p class="input-value">article title: <span class="highlight">{{ article.title }}</span></p>
     <p class="input-value">article tags: <span class="highlight">{{ article.tags }}</span></p>
      <p class="input-value">article description: <span class="highlight">{{ article.description }}</span></p>
      
</div>
   </div>
    <div class="card-body" v-else>
    <btn input-type="radio" input-value="article.hash" v-model="article.hash" disabled> ARTICLE </btn>

  <hr/>
  <alert>Hash: {{ article.hash }}</alert>
     
     <div id="intro">
  
            </div>
  <div form-control v-if="article">          
<form class="form" @submit.prevent="checkForm">
  <div class="form-group">
    <label class="sr-only">Title</label>
    <p class="form-control-static">Article Title</p>

  <div class="form-group mx-sm-3">
    <label for="title" class="sr-only">Title</label>
    <input v-debounce="delay" type="title" class="form-control" id="title" input-value="article.title" v-model.lazy="article.title">
  </div>
  </div>
  <div class="form-group">
    <label class="sr-only">Tags</label>
    <p class="form-control-static">Tags</p>

  <div class="form-group mx-sm-3">
    <label for="tags" class="sr-only">Texy</label>
    <input v-debounce="delay" type="text" class="form-control" id="tags" input-value="article.tags" v-model.lazy="article.tags">
  </div>
  </div>
   <div class="form-group">
    <label class="sr-only">Description</label>
    <p class="form-control-static">Tags</p>

  <div class="form-group">
    <label for="inputDescription" class="sr-only">Description</label>
    <input v-debounce="delay" type="text" class="form-control" id="inputDescription" input-value="article.description" v-model.lazy="article.description">
  </div>
   </div>
  <button type="submit" class="btn btn-primary">Confirm Update</button>
   <btn type="danger" class="mt-5 mb-5"
        @click="deleteCurrentArticle">
        Delete Article</btn>
</form>
    <p class="input-value">article created: <span class="highlight">{{ article.createdAt }}</span></p>
   <div id='author' class="box" v-if="author">
     
      <p class="input-value">article author - name: <span class="highlight">{{ author.firstName}} {{author.lastName }}</span></p>
        <p class="input-value">article author - username: <span class="highlight">{{ author.username }}</span></p>
            <p class="input-value">authorHash - userhash: <span class="highlight">{{ article.userHash }}</span></p>
            <p class="input-value">authorTel - phone: <span class="highlight">{{ article.phone }}</span></p>
            <p class="input-value">authorSkype - skype: <span class="highlight">{{ article.skype }}</span></p>
  </div>
    </div>
    </div>
    </section>
</template>

<script>
  import _ from 'lodash';
  import {
    mapGetters
  } from 'vuex';
  import debounce from '../components/architecture/services';
  const fetchInitialAticle = (store) => store.dispatch(`getArticleByHash`, store.state.route.params.hash)
  const fetchAuthorOfAticle = (store) => store.dispatch(`getUserByHash`, store.state.article.userHash);
  const delArticle = (store) => store.dispatch(`deleteArticleByHash`);
  const updateArticle = (store) => store.dispatch(`updateArticleByHash`);
  const applyForArticle = (store) => new Promise((res, rej) => res(fetchInitialAticle(store)));
  const applyForAuthor = (store) => applyForArticle(store).then(() => fetchAuthorOfAticle(store));
    export default {
  prefetch1: fetchInitialAticle,
  data () {
      return {
        errors: [],
        delay:300
                      }
    },
    directives: {
      debounce
    },
      computed: {
           ...mapGetters({
        user: 'getUser',
       article: 'getArticle',
          author: 'getAuthor'
               }),
     isAdmin: function() {
      if (this.user) {
        if (_.indexOf(this.user.roles, "admin") >= 0) return true;
        else return false;
      }
      return false;
    },
    },
    wath: {
       article: {
      handler: function (article) {
        this.$store.commit('update_article', article);
         },
         deep: true
      }
    },
    methods: {
      deleteCurrentArticle: function(){
       delArticle(this.$store)
       .then(() => {
            this.$router.push('/')
          })
          .catch(err => {
            console.log(err)
            window.alert('Error: data erasing...')
          })
      },
      checkForm:function(e) {
      e.preventDefault();
      this.errors = [];
      if(this.article.title === '') {
        this.errors.push("Article Title is required.");
      } else {
      updateArticle(this.$store, this.article )
        .then(() => {
            this.$router.push('/')
          })
          .catch(err => {
            console.log(err)
            window.alert('Error: data updating...')
          })
        }
      }
    },
    mounted() {
     if (!this.author) {
      applyForAuthor(this.$store)
     }
   },
   beforeDestroy() {
      this.$store.commit(`clear_article`);
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
 </style>