<template>
 <!--div>
    <div class="jumbotron">
      <articles></articles>
      <div class="container">
     </div>
    </div>
    </div!-->
</template>

<script>

export default {
  title() {
    return 'Koa Vue SSR'
  },

}
</script>

<style lang="postcss">

</style>
