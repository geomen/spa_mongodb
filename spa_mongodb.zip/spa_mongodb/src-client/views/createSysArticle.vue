<template>
  <section class="container">
     <div id="intro">
      </div>
      <div class="form">
      <form class="form" @submit.prevent="checkForm">
        <div class="form-group">
          <label class="sr-only">Title</label>
          <p class="form-control-static">Article Title</p>
  
          <div class="form-group mx-sm-3">
            <label for="title" class="sr-only">Title</label>
            <input v-debounce="delay" type="text" class="form-control" id="title" input-value="article.title" v-model.lazy="article.title">
          </div>
        </div>
        <div class="form-group">
          <label class="sr-only">Tags</label>
          <p class="form-control-static">Tags</p>
  
          <div class="form-group mx-sm-3">
            <label for="tags" class="sr-only">Tags</label>
            <input v-debounce="delay" type="text" class="form-control" id="tags" input-value="article.tags" v-model.lazy="article.tags">
          </div>
        </div>
        <div class="form-group">
          <label class="sr-only">Description</label>
          <p class="form-control-static">Desscription</p>
  
          <div class="form-group">
            <label for="inputDescription" class="sr-only">Description</label>
            <input v-debounce="delay" type="text" class="form-control" id="inputDescription" input-value="article.description" v-model.lazy="article.description">
          </div>
        </div>
        <button type="submit" class="btn btn-primary">Confirm Create</button>
  
      </form>
    </div>
  </section>
</template>

<script>
  import {
    mapGetters
  } from 'vuex';
  import debounce from '../components/architecture/services';
  export default {
    data() {
      return {
        article: {
          tags: [],
          title: '',
          description: '',
            },
           delay: 500
      }
    },
       directives: {
      debounce
    },
    methods: {
      checkForm: function(e) {
        e.preventDefault();
        this.errors = [];
        if (this.article.title === '') {
          this.errors.push("Article Title is required.");
        } else {
          this.$store.dispatch('createArticle', this.article)
            .then(() => this.$router.push('/home'))
            .catch(err => {
              console.log(err)
              window.alert('Error: data creating...')
            })
        }
      }
    },
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>
  
</style>
