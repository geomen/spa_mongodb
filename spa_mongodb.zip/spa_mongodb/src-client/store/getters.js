export const getArticles = state => state.articles;
export const getPagination = state => state.pagination;
export const getArticle = state => state.article;
export const getUser = state => state.user;
export const getAuthor = state => state.author;
export const getFilter = state => state.filter;
export const getToken = state => state.token;
