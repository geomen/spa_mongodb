import Vue from 'vue';
import Vuex from 'vuex';
import * as actions from './actions';
import * as getters from './getters';

Vue.use(Vuex);

const state = {
    pagination: {
        currentPage: 1,
        limit: 10,
        totalPages: 0,
        totalArticles: 0,
    },
    filter: {
        tags: [],
        title: ''
    },
    articles: {},
    article: {
        title: '',
        tags: '',
        description: ''
    },
    user: null,
    token: null,
    author: {}
};

const mutations = {
    article_list: (state, data) => {
        state.articles = data.data;
        state.pagination.totalPages = data.pages;
        state.pagination.totalArticles = data.count;
        state.pagination.currentPage = data.filter.page;
        state.pagination.limit = data.filter.size;
    },
    article_hash: (state, article) => {
        state.article = article.data;
    },
    author_hash: (state, author) => {
        console.log('muttations', author);
        state.author = author;
    },
    set_tags: (state, tags) => {
        state.filter.tags = tags;
    },
    clear_article: (state) => {
        state.article = null;
        state.author = null;
    },
    set_title: (state, title) => {
        state.filter.title = title;
    },
    login: (state, data) => {
        state.user = data;
    },
    set_user: (state, data) => {
        state.user = data;
    },
    logout: (state) => {
        state.user = null;
    }
};
/* const store = new Vuex.Store({
  state: {
    activeType: 'home',
    articles: [], // 文章列表
    accounts: [], // 微信公众号列表
    category: [], // 公众号分类列表
  }
})

export default store */

export function createStore() {
    return new Vuex.Store({
        state,
        actions,
        getters,
        mutations
    });
}
