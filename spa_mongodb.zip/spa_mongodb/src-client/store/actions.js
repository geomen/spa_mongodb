import axios from 'axios';

export const getArticles = ({ commit, state }, pN = 1) => {
    let url = `http://localhost:8080/api/articles?page=${pN}`;
    const { tags, title } = state.filter;
    if (tags) url = url.concat(`&tags=${tags}`);
    if (title) url = url.concat(`&title=${title}`);
    axios.get(url)
        .then((response) => {
        //    console.log('!!!!!!!!!!!!!!!! from actions Article ', response.data);
            commit('article_list', response.data);
        });
};
export const getArticleByHash = ({ commit }, hash) => axios.get(`http://localhost:8080/api/articles/${hash}`)
    .then((response) => {
        console.log('!!!!!!!!!!!!!!!! from actions getByHashArticle ', response);
        commit('article_hash', response.data);
    });
export const updateArticleByHash = ({ commit, state }) => {
    axios.put(`http://localhost:8080/api/sys/${state.article.hash}`, state.article)
        .then((response) => {
        //     console.log('!!!!!!!!!!!!!!!! from actions updateByHashArticle ', response.data);
            commit('article_hash', response.data);
        });
};
export const createArticle = ({ commit, state }, data) => {
    // console.log('!!!!!!!!!!!!!!!! from actions createByHashArticle ', data);
    axios.post(`http://localhost:8080/api/sys/${state.user.hash}`, data)
        .then((response) => {
            console.log('!!!!!!!!!!!!!!!! from actions updateByHashArticle ', response.data);
            commit('article_hash', response.data);
        });
};
export const deleteArticleByHash = ({ commit, state }) => {
    axios.delete(`http://localhost:8080/api/sys/${state.article.hash}`)
        .then(() => {
            //   console.log('!!!!!!!!!!!!!!!! from actions deleteByHashArticle ', response);
            commit('clear_article');
        });

/*    return new Promise((resolve, reject) => {
        setTimeout(() => {
            commit('clear_article');
            resolve();
        }, 800);
    }); */
};

export const getUserByHash = ({ commit }, data) => {
    axios.get(`http://localhost:8080/api/user/${data}`)
        .then((response) => {
            //   console.log('!!!!!!!!!!!!!!!! from actions getByHashUSER ', response.data);
            commit('author_hash', response.data.data);
        });
};
export const login = ({ commit }, data) => {
    axios.post('/api/auth/login', data)
        .then(response => {
            //   console.log('!!!!!!!!!!!!!!!! from actions user Login data.data ', response.data.data);
            commit('login', response.data.data);
        })
        .catch((err) => console.log(err));
};
export const logout = ({ commit }) => {
    axios.post('/api/auth/logout')
        .then(() => {
            commit('logout');
        });
};

