import Vue from 'vue';
import Router from 'vue-router';
// import _ from 'lodash';
// import app from '../app';

Vue.use(Router);

const router = new Router({
    mode: 'history',
    scrollBehavior: () => ({ y: 0 }),
    base: __dirname,
    linkActiveClass: 'active',
    routes: [
        { path: '/', redirect: '/home' },
        { path: '/home', component: () => import('@/views/Home') },
        { path: '/auth/register', component: () => import('@/views/auth/Register') },
        { path: '/auth/login', component: () => import('@/views/auth/Login') },
        { path: '/sys/:hash', component: () => import('@/views/createSysArticle') },
        /* , meta: { roles: ['admin'] }  },
        // { path: '/article/sys/:hash', component: () => import('@/views/Options.vue'),
        meta: { roles: ['admin'] } }, */
        { path: '/articles/:hash', component: () => import('@/views/Single.vue') },
        { path: '*', redirect: '/' }
    ]
});
/* router.beforeRouteEnter = (to, from, next) => {
    next(vm => vm.$store.dispatch('loadLeaderboard'));
}; */
/* eslint-disable
router.beforeEach((to, from, next) => {
    if (to.meta && to.meta.roles) {
        const loginPath = { path: '/auth/login' };
        // let user = router.app.$store.state.user
        const user = { roles: ['user', 'admin'] };
        if (!user) {
            next(loginPath);
        }else {
         //   const roles = to.meta.roles;
          //  roles: ['user', 'admin'];
            let match = true; //false
             for (let i = 0, l = user.roles.length; i < l; i++) {
                const role = user.roles[i];
                if (_.indexOf(roles, role) >= 0) {
                    match = true;
                    break;
                }
            }
            if (match) {
                next();
            } else {
                next(loginPath);
            }
        }
    } else {
        next();
    }
});
*/

export function createRouter() {
    return router;
}
