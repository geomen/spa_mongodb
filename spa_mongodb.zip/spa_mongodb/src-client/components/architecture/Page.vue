<template>
  <section class="page">
      <router-view :key="$route.path"></router-view>
      <div class="jumbotron">
     <div class="container">
      <articles></articles>
     </div>
    </div>
    </section>
</template>

<script>
import Articles from '@/components/architecture/Articles.vue'

  export default {
      components: {
    Articles
  }
  }
</script>

<style lang="less" rel="stylesheet/less" scoped>
  .page {
    margin-bottom: 50px; /* Height of footer*/
  }
</style>
