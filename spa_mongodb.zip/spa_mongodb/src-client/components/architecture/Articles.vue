<template>
  <div class="container" v-if="articles" >
    <div class="row">
      <div class="col-xs-12">
        <div class="column">
          <div class="col-md-6 col-md-offset-3">
            <div>
              <input v-debounce="delay" placeholder="Filter by tags" v-model.lazy="tagsSearch" class="form-input input-sm" />
              <h6>{{ feedback }}</h6>
            </div>
            <div v-if="isAdmin">
              <input v-debounce="delay" placeholder="Filter by title" v-model.lazy="titleSearch" class="form-input input-sm" />
              <h6>{{ feedback }}</h6>
            </div>
          </div>
          <table class="table">
            <thead>
              <tr>
                <th>Tags</th>
                <th>Title</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="article in articles" :key="article.hash">
                <td>{{article.tags}}</td>
                <td>{{article.title}}</td>
                <td>{{article.description}}</td>
                <td>
                  <router-link :to="'/articles/'+article.hash">View</router-link>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="container" align="center">
            <pagination :current-page="pagination.currentPage" :total-pages="pagination.totalPages" :items-per-page="pagination.limit" :total-items="pagination.totalArticles" @page-changed="getPostData">
            </pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios';
  import _ from 'lodash';
  import debounce from './services';
  import Pagination from './Pagination.vue';
  import {
    mapGetters
  } from 'vuex';
  const fetchInitialData = store => {
    return store.dispatch(`getArticles`)
  }
  export default {
    prefetch: fetchInitialData,
    components: {
      Pagination
    },
    data() {
      return {
        tagsSearch: '',
        titleSearch: '',
        feedback: 'pls type tags for query...',
        delay: 800
      }
    },
    directives: {
      debounce
    },
    watch: {
      tagsSearch: function(newQuestion, oldQuestion) {
        this.feedback = 'waiting until print,pls type tags by commas an spaces ';
        let tags = _.words(this.tagsSearch);
        this.$store.commit('set_tags', tags);
        this.getPostData();
      },
      titleSearch: function(newQuestion, oldQuestion) {
        this.feedback = 'waiting until print,pls type title by commas an spaces ';
        let title = this.titleSearch;
        this.$store.commit('set_title', title);
        this.getPostData();
      },
    },
    computed: {
      ...mapGetters({
        filter: 'getFilter',
        articles: 'getArticles',
        pagination: 'getPagination',
        user: 'getUser'
      }),
      isAdmin: function() {
        if (this.user) {
          if (_.indexOf(this.user.roles, "admin") >= 0) return true;
        }
        return false;
      },
    },
    methods: {
      getPostData(pageNum) {
        pageNum = pageNum || this.pagination.currentPage;
        this.$store.dispatch('getArticles', pageNum, this.filter)
      }
    },
    //Called when page rendered
    beforeCreate() {
       fetchInitialData(this.$store)
              }
  }
</script>

<style scoped>
  
</style>

