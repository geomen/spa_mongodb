export default {

    lowerBound(num, limit) {
        return num >= limit ? num : limit;
    }
};
