<template>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <p>@Geo 2018</p>
        </div>
      </div>
    </div>
  </footer>
</template>

<script>
import _ from 'lodash';
import { mapGetters, mapState } from 'vuex';
  export default {
    name: 'pageFooter',
    serverCacheKey: () => 'pageFooter',
    data(){

    },
 /*     asyncComputed: {
            ...mapState(['token']),
       },
watch:{
     token: {
     handler: _.debounce(function () {
        this.$store.dispatch('fetchCU');
      }, 200), deep: false
         },
    } */
  }
 </script>

<style lang="less" rel="stylesheet/less" scoped>
  footer {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 10px;
    border-top: 1px solid #ddd;
  }
</style>
