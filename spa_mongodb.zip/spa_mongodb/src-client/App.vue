<template>
 <section id="app">
    <page-wrapper></page-wrapper>
  </section>
</template>

<script>
 import PageWrapper from './components/architecture/PageWrapper.vue'
export default {
   name: 'APP',
 components: {PageWrapper}
}
</script>

<style>
@import "./../node_modules/bootstrap/dist/css/bootstrap.css";
@import './assets/css/core.less'; 
/* normalize 
@import './assets/css/normalize.css';
/* @import './components/Menu/base.css';
@import './components/Menu/horizontal.css';
@import './components/Button/base.css';
 */
</style>
