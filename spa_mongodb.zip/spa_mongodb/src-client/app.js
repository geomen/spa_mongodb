import AsyncComputed from 'vue-async-computed';
import Vue from 'vue';
import * as uiv from 'uiv';
import { sync } from 'vuex-router-sync';
import App from './App';
import { createStore } from './store';
import { createRouter } from './router';
import title from './mixins/title';

Vue.mixin(title);
Vue.use(uiv);
Vue.use(AsyncComputed);
export function createApp() {
    const router = createRouter();
    const store = createStore();

    sync(store, router);

    const app = new Vue({
        router,
        store,
        render: h => h(App)
    });

    return { app, router, store };
}
