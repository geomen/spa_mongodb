/* eslint max-len: [1, 140, 4] */
module.exports = {
    server: {
        allJS: ['server.js', 'config/**/*.js', 'src-server/*/**/*.js'],
        models: ['src-server/articles/models/**/*.js', 'src-server/user/models/**/*.js'],
        routes: ['src-server/!(core)/routes/**/*.js', 'src-server/articles/routes/**/*.js', 'src-server/user/routes/**/*.js'],
        sockets: 'src-server/*/sockets/**/*.js',
        config: ['src-server/*/config/*.js'],
        policies: 'src-server/*/policies/*.js',
        views: ['src-server/*/views/*.html']
    }
    // 'src-server/*/models/**/*.js'
};
