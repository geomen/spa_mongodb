import faker from 'faker/locale/ru';
import _ from 'lodash';
import { User } from '../../src-server/user/models';

const adminPromise = User.create({
    email: 'admin@localhost.com',
    password: 'admin',
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    provider: 'local',
    roles: ['user', 'admin'],
    username: 'sysadmin'
});
/* eslint max-len: [1, 140, 4] */
export default () => {
    const promises = [];
    promises.push(adminPromise);
    _.times(200, () => {
        const userPromise = User.create({
            email: `${faker.lorem.word(1, 15)}-${faker.random.number((faker.random.number(1, 5555)), 9999)}-${faker.lorem.word(1, 5)}@${faker.lorem.word(1, 10)}.${faker.internet.domainSuffix()}`,
            firstName: faker.name.firstName(),
            lastName: faker.name.lastName(),
            password: User.generateRandomPassphrase(),
            provider: 'local',
            roles: ['user'],
            username: `${faker.internet.userName()}-${faker.random.number(1, 9999)}-${faker.lorem.word(1, 5)}`
        });
        promises.push(userPromise);
    });

    return Promise.all(promises);
};
