import mongoose from '../lib/mongoose';
import userSeeds from './user-seeds';
import articleSeeds from './article-seeds';

async function initSeeds() {
    try {
        const users = await userSeeds();
        const articles = await articleSeeds(users);

        console.log(articles);
    } catch (e) {
        console.error(e);
    } finally {
        mongoose.disconnect();
    }
}
mongoose.loadModels(() => {
    mongoose.connect()
        .then(async(mongodb) => { console.log('Mongo connected'); await mongodb.connection.db.dropDatabase(); })
        .then(initSeeds())
        .catch((err) => console.log(err));
});
