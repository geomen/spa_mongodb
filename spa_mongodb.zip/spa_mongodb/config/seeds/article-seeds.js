import faker from 'faker';
import _ from 'lodash';
import { Article } from '../../src-server/articles/models';

export default (users) => {
    if (!users || !users.length) {
        throw Error('users is required');
    }

    const promises = [];

    _.times(200, () => {
        const articlePromise = Article.create({
            title: faker.lorem.words(2, 5),
            description: faker.lorem.lines(4, 10),
            phone: faker.phone.phoneNumber(),
            skype: faker.internet.userName(),
            tags: faker.lorem.words(3, 16).split(' '),
            userHash: users[faker.random.number(199)].hash
        });

        promises.push(articlePromise);
    });

    return Promise.all(promises);
};
