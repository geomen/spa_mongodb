/* eslint-disable */
const path = require('path');

module.exports = {
    secure: {
    // ssl: true,
    // privateKey: './config/sslcerts/key.pem',
    // certificate: './config/sslcerts/cert.pem',
    // caBundle: './config/sslcerts/cabundle.crt'
        ssl: false
    },
    migrate: 'safe',
    port: process.env.PORT || 3000,
    // Binding to 127.0.0.1 is safer in production.
    host: process.env.HOST || '0.0.0.0',
    db: {
        uri: process.env.MONGOHQ_URL || process.env.MONGODB_URI || ,
        options: {
            socketTimeoutMS: 0,
            keepAlive: true,
            reconnectTries: 30
            /**
       * Uncomment to enable ssl certificate based authentication to mongodb
       * servers. Adjust the settings below for your specific certificate
       * setup.
       server: {
        ssl: true,
        sslValidate: false,
        checkServerIdentity: false,
        sslCA: fs.readFileSync('./config/sslcerts/ssl-ca.pem'),
        sslCert: fs.readFileSync('./config/sslcerts/ssl-cert.pem'),
        sslKey: fs.readFileSync('./config/sslcerts/ssl-key.pem'),
        sslPass: '1234'
      }
       */
        },

        // Enable mongoose debug mode
        debug: process.env.MONGODB_DEBUG || false
    },
    log: {
    // logging with Morgan - https://github.com/expressjs/morgan
    // Can specify one of 'combined', 'common', 'dev', 'short', 'tiny'
        format: process.env.LOG_FORMAT || 'combined',
        fileLogger: {
            directoryPath: process.env.LOG_DIR_PATH || path.join(__dirname, './../../log'),
            fileName: process.env.LOG_FILE || 'app.log',
            maxsize: 10485760,
            maxFiles: 2,
            json: false
        }
    }

};
