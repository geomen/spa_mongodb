import mongoose from 'mongoose';
import passport from 'koa-passport';
import { Strategy } from 'passport-local';
import jwtService from '../../src-server/user/services/jwt-service';
import userService from './../../src-server/user/services/user-service';

const User = mongoose.model('User');

const fetchUser = async(id, usernameOrEmail) => {
    let user = mongoose.model('User');
    if (id) {
        const { email } = jwtService.verify(id.id);
        user = await userService.getUserMainFields({ email }); // User.findById(id);
    } else {
        user = await User.findOne({ // User.findOne({
            $or: [{
                username: usernameOrEmail
            }, {
                email: usernameOrEmail
            }]
        }).select({ __v: 0, createdAt: 0, updatedAt: 0 });
    }

    return user;
};
passport.serializeUser((user, done) => {
    done(null, user._id);
});

passport.deserializeUser(async(id, done) => {
    const user = await fetchUser(id);
    done(null, user);
});
passport.use(new Strategy(
    {
        usernameField: 'email',
        passwordField: 'password',
        passReqToCallback: true,
    },
    ((ctx, usernameOrEmail, password, done) => {
        fetchUser(null, usernameOrEmail)
            .then((user) => {
                if (!user || !user.authenticate(password)) {
                    return done(null, false, {
                        message: `Invalid username or password (${(new Date()).toLocaleTimeString()})`
                    });
                }

                return done(null, user);
            })
            .catch((err) => done(err));
    })
));

