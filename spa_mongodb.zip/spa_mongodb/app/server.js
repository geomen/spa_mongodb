const app = require('../config/lib/app');

app.start();
