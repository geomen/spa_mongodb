import mongoose, { Schema } from 'mongoose';
import bcrypt from 'bcrypt';
import uuid from 'uuid/v4';
import uniqueValidator from 'mongoose-unique-validator';
import generatePassword from 'generate-password';

// const crypto = require('crypto')
const userSchema = new Schema({
    active: Boolean,
    email: {
        type: String,
        unique: 'user with email "{VALUE}" already exist',
        lowercase: true,
        required: 'Email is required',
        trim: true
    },
    hash: {
        type: String,
        unique: 'Hash mast be unique'
    },
    password: {
        type: String,
        required: 'Password is required',
        trim: true
    },
    username: {
        type: String,
        required: 'Username is required',
        trim: true
    },
    firstName: {
        type: String,
        lowercase: true,
        required: 'Firts name is required',
        trim: true
    },
    lastName: {
        type: String,
        lowercase: true,
        required: 'Last name is required',
        trim: true
    },
    provider: {
        type: String,
        required: 'Provider is required'
    },
    providerData: {},
    additionalProvidersData: {},
    roles: {
        type: [{
            type: String,
            'enum': ['user', 'admin']
        }],
        'default': ['user'],
        required: 'Please provide at least one role'
    }

}, {
    timestamps: true
});
userSchema.plugin(uniqueValidator);
userSchema.pre('save', function(next) {
    if (this.isModified('password')) {
        const salt = bcrypt.genSaltSync(10);
        this.password = bcrypt.hashSync(this.password, salt);
        console.log('model pre schema, password:', this.password);
    }

    if (!this.hash) {
        this.hash = String(uuid());
    }

    next();
});
userSchema.statics.createFields = ['email', 'firstName', 'lastName', 'password', 'username', 'hash', 'roles'];
userSchema.methods.authenticate = function(password) {
    //   console.log(password, this.password);
    return bcrypt.compareSync(password, this.password, (err, res) => {
        if (err) {
        //    console.log('Comparison error: ', err);
        } else {
        //   console.log('password matched: ', res);
        }
    });
};
userSchema.statics.generateRandomPassphrase = () => {
    let password = '1111';
    const repeatingCharacters = new RegExp('(.)\\1{2,}', 'g');

    // iterate until the we have a valid passphrase
    // NOTE: Should rarely iterate more than once, but we need this to ensure no repeating characters are present
    while (password.length < 20 || repeatingCharacters.test(password)) {
        // build the random password
        password = generatePassword.generate({
            length: Math.floor(Math.random() * (20)) + 20, // randomize length between 20 and 40 characters
            numbers: true,
            symbols: false,
            uppercase: true,
            excludeSimilarCharacters: true
        });

        // check if we need to remove any repeating characters
        password = password.replace(repeatingCharacters, '');
    }

    return password;
};
export default mongoose.model('User', userSchema);
