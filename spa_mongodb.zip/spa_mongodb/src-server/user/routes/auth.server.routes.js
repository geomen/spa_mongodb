import Router from 'koa-router';
import passport from 'koa-passport';
import AuthController from './../controllers/auth.server.controller';
import checkUser from '../services/checkUser';
// import getUsersHash from '../handlers/getUsersHash';

module.exports = (router) => {
    const apiRouter = new Router({
        prefix: '/api/auth'
    })
        .post('/register', AuthController.register)
        .post('/login', passport.authenticate('local'), AuthController.login)
        .get('/user/', checkUser(), AuthController.currentUser)
        .post('/logout', AuthController.logout);
    router.use(apiRouter.routes());
};

/* for testing local-passport
(req, res, next) => {
            passport.authenticate('local', (err, user, info) => {
                if (err) { return next(err); }
                if (!user) {
                // *** Display message without using flash option
                // re-render the login form with a message
                    return res.render('login', { message: info.message });
                }
                req.logIn(user, (err) => {
                    if (err) { return next(err); }
                });
            })(req, res, next);
        },
*/
