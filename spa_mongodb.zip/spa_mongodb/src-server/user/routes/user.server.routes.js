import Router from 'koa-router';
import checkUserByHash from './../handlers/checkUserByHash';
import UserController from './../controllers/user.server.controller';
import checkUser from '../services/checkUser';

module.exports = (router) => {
    const apiRouter = new Router({
        prefix: '/api/user'
    })
        .param('hash', checkUserByHash())
        .get('/:hash', checkUser(), UserController.getUserByHash)
        .get('/:hash/articles', UserController.getArticlesByUserHash);
    router.use(apiRouter.routes());
};

