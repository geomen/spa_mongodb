import Router from 'koa-router';
import AdminController from './../controllers/admin.server.controller';
import checkUser from '../services/checkUser';
import checkArticle from '../controllers/admin-services/checkArticle';
// import getUsersHash from './../handlers/getUsersHash';

module.exports = (router) => {
    const apiRouter = new Router({
        prefix: '/api/sys'
    })
        .get('/', checkUser(), AdminController.searchArticles)
        .param('hash', checkArticle())
        .post('/:hash', checkUser(), AdminController.create)
        .get('/:hash', checkUser(), AdminController.getArticle)
        .put('/:hash', checkUser(), AdminController.update)
        .delete('/:hash', checkUser(), AdminController.delete);
    router.use(apiRouter.routes());
};
