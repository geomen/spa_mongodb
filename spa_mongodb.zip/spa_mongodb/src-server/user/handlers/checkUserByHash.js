import mongoose from 'mongoose';

const User = mongoose.model('User');
export default () => async(hash, ctx, next) => {
    //   console.log('checkUserby Hash', hash);
    const user = await User.findOne({ hash });
    //   console.log('checkUserby Hash', user);
    if (!user) {
        ctx.throw(404, `User with hash "${hash}" not found`);
    }

    ctx.state.user = user;

    await next();
};
