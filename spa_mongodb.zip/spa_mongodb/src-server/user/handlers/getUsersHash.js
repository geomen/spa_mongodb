import jwtService from '../services/jwt-service';
import userService from '../services/user-service';

export default () => async(ctx, next) => {
    const id = ctx.session.passport.user;
   // console.log('checkadmin: id', id, id.id);
    const { email } = jwtService.verify(id.id);
   // console.log('midleware getUser Hash email:', email);
    const { hash } = await userService.getUserHash({ email }); // User.findById(id);
    ctx.state = { data: { hash } };
  //  console.log('checkUsersHash: hash', hash, ctx.state.data.hash);
    await next();
};
