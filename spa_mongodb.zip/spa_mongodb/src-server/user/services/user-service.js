import mongoose from 'mongoose';

const User = mongoose.model('User');
export default {
    async createUser(data) {
        try {
            return await User.create(data, function(err, user) {
                if (err) {
                    console.log(err);

                return;
            }
            // console.log('User added _id: ', user._id);

                return user._id;
            });
        } catch (e) {
            throw new AppError({ status: 400, ...e });
        }
    },
    async getUserWithPublicFields(params) {
        try {
            return await User.findOne(params).select({ _v: 0, updatedAt: 0, createdAt: 0 });
        } catch (e) {
            throw new AppError({ status: 400, ...e });
        }
    },
    async getUserMainFields(params) {
        try {
            return await User.findOne(params).select({
                _id: 0,
                hash: 2,
                username: 2,
                email: 2,
                roles: 2
            });
        } catch (e) {
            throw new AppError({ status: 400, ...e });
        }
    },
    async getUserHash(params){
        try {
            return await User.findOne(params).select({ hash: 2 });
        } catch (e) {
            throw new AppError({ status: 400, ...e });
        }
    },
};
