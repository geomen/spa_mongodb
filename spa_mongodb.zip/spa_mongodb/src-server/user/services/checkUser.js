// import sessionUtils from '../../../config/lib/session';

export default () => async(ctx, next) => {
    // console.log('checkUser: ', ctx.isAuthenticated());
    //  const { hash } = sessionUtils.getUserJson();
    // console.log('checkUser hash: ', hash);
    if (!ctx.isAuthenticated()) {
        ctx.throw(403, { message: 'Not logged...' });
    }
    await next();
};
