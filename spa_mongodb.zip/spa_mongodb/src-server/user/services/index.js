import userService from './user-service';

export { userService };
