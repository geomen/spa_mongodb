const jwt = require('jsonwebtoken');
const config = require('./../../../config/config');
// import jwt from 'jsonwebtoken';
// import { JWT_SECRET } from '../../config';
exports.genToken = (data) => jwt.sign(data, config.jwtsecret);
exports.verify = (token) => jwt.verify(token, config.jwtsecret);

