import _ from 'lodash';
import mongoose from 'mongoose';
import { ArticleService } from './admin-services';
import parseQueryForSearch from '../../articles/helpers/parseQueryForSearch';
// import sessionUtils from './../../../config/lib/session';

const Article = mongoose.model('Article');

export default {
    async create(ctx) {
        const articleData = {
            ..._.pick(ctx.request.body, Article.workOutFields),
            userHash: ctx.state.data.hash,
        };
        // console.log('Create Article admin articledtat: ', articleData);
        const { _id } = await ArticleService.createArticle(articleData);
        const article = await Article.findOne({ _id });
        // console.log('Create Article admin final issue: ', article);
        ctx.status = 201;
        ctx.body = { data: article };
    },

    async update(ctx) {
        const {
            request: {
                body
            },
            state: {
                article
            }
        } = ctx;
        const newData = _.pick(body, Article.createFields);
        const updatedArticle = await ArticleService.updateArticle(newData, article);

        ctx.body = { data: updatedArticle };
    },
    async delete(ctx) {
        const {
            state: {
                article
            }
        } = ctx;
        await article.remove();
        ctx.body = { data: { id: article.hash } };
    },

    getArticle(ctx) {
        //  console.log('controller.getarticle CTX : ', ctx.state);
        const { state: { article } } = ctx;
        //   console.log('controller.getarticle : ', article);
        ctx.body = { data: _.pick(article, Article.workOutFields) };
        //  console.log(ctx.body.data);
    },

    async searchArticles(ctx) {
        //   console.log('server.controller query search: ', ctx.request.query);
        const queryParams = _.pick(ctx.request.query, ['title', 'tags', 'size', 'page']);
        //   console.log('server.controller query search: ', queryParams);
        const filter = parseQueryForSearch(queryParams);
        const { articles, ...rest } = await ArticleService.search(filter);
        // const sanitized = stringify(articles);
        // console.log('Статьи :', articles);
        ctx.body = {
            data: articles,
            filter,
            ...rest
        };
    },
};
