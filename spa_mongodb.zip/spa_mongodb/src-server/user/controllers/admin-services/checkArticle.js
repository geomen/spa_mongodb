// import { Article } from '../models';
import mongoose from 'mongoose';

const Article = mongoose.model('Article');
export default () => async(hash, ctx, next) => {
    const article = await Article.findOne({ hash });
    //  console.log('check Article1: ', hash);
    if (!article) {
        ctx.throw(404, `Article with link "${hash}" not found`);
    }
    // console.log('check Article2: ', article);
    ctx.state.article = article;

    await next();
};
