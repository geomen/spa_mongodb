import _ from 'lodash';
import mongoose from 'mongoose';

const sessionUtils = require('./../../../config/lib/session');
const jwtService = require('../services/jwt-service');
const { userService } = require('../services');

const User = mongoose.model('User');

exports.register = async(ctx) => {
    const userData = _.pick(ctx.request.body, User.createFields);
    userData.provider = 'local';
    //   console.log(userData);
    delete userData.role;
    const _id = await userService.createUser(userData);
    const user = await userService.getUserWithPublicFields({ _id });
    //   console.log('user controller: ', user);
    ctx.status = 201;
    ctx.body = { user };
};
exports.login = async(ctx) => {
    const { email } = sessionUtils.getUserJson(ctx);
    const token = await jwtService.genToken({ email });
    ctx.session.passport.user = { id: token };
    ctx.body = { data: sessionUtils.getUserJson(ctx) };
    ctx.state.status = 201;
};
exports.logout = async(ctx) => {
    ctx.logout();
    ctx.body = true;
};
exports.currentUser = async(ctx) => {
    const { state: { data: { hash } } } = ctx;
    //  console.log('currentUser', hash);
    const user = userService.getUserMainFields({ hash })
        .then(() => {
            console.log('user', user);
            ctx.state.user = { user };
            ctx.state.status = 201;
        })
        .catch((e) => {
            throw new AppError({ status: 400, ...e });
        });
};
