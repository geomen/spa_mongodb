import mongoose from 'mongoose';
import _ from 'lodash';

const Article = mongoose.model('Article');
const User = mongoose.model('User');
export default {
    async getArticlesByUserHash(ctx) {
        const { state: { user: { hash: userHash } } } = ctx;
        const articles = await Article.find({ userHash });
        ctx.body = { data: articles };
    },
    async getUserByHash(ctx) {
        const { state: { user } } = ctx;
        // console.log('controller.getUserByHash : ', user);
        ctx.body = { data: _.pick(user, User.createFields) };
        //  console.log(ctx.body.data);
    },
};
