export const MAX_SIZE = 10;
export const PAGE = 1;
