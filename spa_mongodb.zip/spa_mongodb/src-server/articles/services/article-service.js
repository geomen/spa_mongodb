// import { Article } from '../models';
import mongoose from 'mongoose';

const Article = mongoose.model('Article');
export default {
    async createArticle(data) {
        const { userHash } = data;
        const articleCountByuserId = await Article.count({ userHash });

        if (articleCountByuserId === 3) {
            throw new AppError({ status: 400, message: 'user can have no more than three articles' });
        }

        return Article.create(data);
    },

    updateArticle(data, article) {
        article.set(data);

        try {
            return article.save();
        } catch (e) {
            throw new AppError({ status: 400, ...e });
        }
    },

    async search({
        tags,
        size,
        page,
        title
    }) {
        const query = {
            title: { $regex: new RegExp(title, 'ig') }
        };

        if (tags.length) {
            query.tags = { $in: tags };
        }

        //  const count = await Article.count(query);
        const count = await Article.count(query);
        const pages = Math.ceil(count / size);
        const articles = await Article
            .find(query)
            .populate('user', '-password')
            .sort({ updatedAt: '-1' })
            .limit(size)
            .skip((page - 1) * size);

        return {
            articles,
            count,
            pages
        };
    }
};
