import _ from 'lodash';
import mongoose from 'mongoose';
import { ArticleService } from '../services';
import parseQueryForSearch from '../helpers/parseQueryForSearch';

const Article = mongoose.model('Article');
export default {
    async create(ctx) {
        const articleData = {
            ..._.pick(ctx.request.body, Article.createFields),
            userHash: ctx.state.user.hash
        };

        const { _id } = await ArticleService.createArticle(articleData);
        const article = await Article.findOne({ _id });

        ctx.status = 201;
        ctx.body = { data: article };
    },

    async update(ctx) {
        // console.log('update CTX.REQEST.BODY', ctx);
        const {
            request: {
                body
            },
            state: {
                user: {
                    hash
                },
                article
            }
        } = ctx;
        if (article.userHash !== hash) {
            ctx.throw(403, `Forbidden. Summary with hash "${article.hash}" dont belong to user with hash ${hash}`);
        }
        const newData = _.pick(body, Article.createFields);
        const updatedArticle = await ArticleService.updateArticle(newData, article);

        ctx.body = { data: updatedArticle };
    },

    async delete(ctx) {
        const {
            state: {
                user: {
                    hash
                },
                article
            }
        } = ctx;

        if (article.userHash !== hash) {
            ctx.throw(403, `Forbidden. Article with hash "${article.hash}" dont belong to user with id ${hash}`);
        }

        await article.remove();

        ctx.body = { data: { id: article.hash } };
    },

    getArticle(ctx) {
        // console.log('controller.getarticle CTX : ', ctx.state);
        const { state: { article } } = ctx;
        // console.log('controller.getarticle : ', article);
        ctx.body = { data: _.pick(article, Article.workOutFields) };
        // console.log(ctx.body.data);
    },

    async searchArticles(ctx) {
        // console.log('server.controller query search: ', ctx.request.query);
        const queryParams = _.pick(ctx.request.query, ['title', 'tags', 'size', 'page']);
        // console.log('server.controller query search: ', queryParams);
        const filter = parseQueryForSearch(queryParams);
        const { articles, ...rest } = await ArticleService.search(filter);
        // const sanitized = stringify(articles);
        // console.log('Статьи :', articles);
        ctx.body = {
            data: articles,
            filter,
            ...rest
        };
    },
};
