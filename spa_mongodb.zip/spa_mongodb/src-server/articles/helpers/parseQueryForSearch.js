import {
    MAX_SIZE,
    PAGE
} from '../constants/pagination';

export default (queryParams) => {
    // console.log('parseQuerySearch input queryParams: ', queryParams);
    // console.log('parseQuerySearch input queryParams - page: ', queryParams.page);
    const search = {
        title: queryParams.title ? queryParams.title : '',
        tags: queryParams.tags ? queryParams.tags.split(',') : [],
        size: parseInt(queryParams.size),
        page: parseInt(queryParams.page)
    };
    // console.log('parseQuerySearch parseInt pass - page: ', search.page);
    if (!search.size || search.size > MAX_SIZE) {
        search.size = MAX_SIZE;
    }

    if (!search.page) {
        search.page = PAGE;
    }
    // console.log('parseQuerySearch verifacation pass - page: ', search.page);

    return search;
};
