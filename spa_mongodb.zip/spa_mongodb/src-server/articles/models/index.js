import Article from './article.server.model';

export default {
    Article
};
