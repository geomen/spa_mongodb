import mongoose, { Schema } from 'mongoose';
import uuid from 'uuid/v4';

const ArticleSchema = new Schema({
    userHash: {
        type: String,
        required: 'user hash is required'
    },
    hash: {
        type: String,
        unique: 'Hash mast be unique'
    },
    title: {
        type: String,
        required: 'Title is required',
        trim: true
    },
    phone: {
        type: String,
        trim: true
    },
    skype: {
        type: String,
        trim: true
    },
    description: {
        type: String,
        required: 'Description is required',
        trim: true
    },
    tags: {
        type: [String],
        required: 'Tags is required',
        trim: true
    }
}, { timestamps: true, toJSON: { virtuals: true } });
/* eslint-disable */
ArticleSchema.statics.workOutFields = ['title', 'phone', 'userHash', 'skype', 'description', 'tags', 'createdAt', 'hash'];
ArticleSchema.statics.createFields = ['title', 'phone', 'skype', 'description', 'hash', 'tags'];
ArticleSchema.virtual('User', {
    ref: 'User',
    localField: 'userHash',
    foreignField: 'hash',
    justOne: true
});

ArticleSchema.pre('save', function(next) {
    if (!this.hash) {
        this.hash = String(uuid());
    }

    next();
});

export default mongoose.model('Article', ArticleSchema);
