import Router from 'koa-router';
import articleController from '../controllers/articles.server.controller';
import checkArticle from '../handlers/checkArticle';
import checkUser from '../../user/services/checkUser';
// import checkUserByHash from '../../user/handlers/checkUserByHash';

module.exports = (router) => {
    const apiRouter = new Router({
        prefix: '/api/articles'
    })
        .post('/', checkUser(), articleController.create)
        .get('/', articleController.searchArticles)
        .param('hash', checkArticle())
        .get('/:hash', articleController.getArticle)
        .put('/:hash', articleController.update)
        .delete('/:hash', articleController.delete);
    router.use(apiRouter.routes());
};
